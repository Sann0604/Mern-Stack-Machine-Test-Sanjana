import React from 'react'

const Logout = () => {
  return (
    <div>
        <h3>Logout Successful</h3>
    </div>
  )
}

export default Logout